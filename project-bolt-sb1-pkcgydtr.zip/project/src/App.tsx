import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Brain, Activity, AlertCircle } from 'lucide-react';
import { cn } from './lib/utils';

interface FormData {
  radius_mean: number;
  texture_mean: number;
  perimeter_mean: number;
  area_mean: number;
  smoothness_mean: number;
  compactness_mean: number;
  concavity_mean: number;
  concave_points_mean: number;
  symmetry_mean: number;
  fractal_dimension_mean: number;
}

function App() {
  const [formData, setFormData] = useState<FormData>({
    radius_mean: 0,
    texture_mean: 0,
    perimeter_mean: 0,
    area_mean: 0,
    smoothness_mean: 0,
    compactness_mean: 0,
    concavity_mean: 0,
    concave_points_mean: 0,
    symmetry_mean: 0,
    fractal_dimension_mean: 0,
  });

  const [prediction, setPrediction] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call with the trained model
    setTimeout(() => {
      // Random prediction for demo
      const result = Math.random() > 0.5 ? 'Benign' : 'Malignant';
      setPrediction(result);
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-pink-50">
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-12">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="inline-block p-3 bg-blue-100 rounded-full mb-4"
            >
              <Brain className="w-12 h-12 text-blue-600" />
            </motion.div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Breast Cancer Prediction System
            </h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Advanced AI-powered system for early breast cancer detection using machine learning analysis of medical data.
            </p>
          </div>

          {/* Main Form */}
          <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-700 mb-4">Cell Nucleus Measurements</h3>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Mean Radius</label>
                  <input
                    type="number"
                    step="0.01"
                    name="radius_mean"
                    value={formData.radius_mean}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Mean Texture</label>
                  <input
                    type="number"
                    step="0.01"
                    name="texture_mean"
                    value={formData.texture_mean}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                {/* Add more input fields for other features */}
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-700 mb-4">Additional Measurements</h3>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Mean Perimeter</label>
                  <input
                    type="number"
                    step="0.01"
                    name="perimeter_mean"
                    value={formData.perimeter_mean}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Mean Area</label>
                  <input
                    type="number"
                    step="0.01"
                    name="area_mean"
                    value={formData.area_mean}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                {/* Add more input fields for other features */}
              </div>

              <div className="md:col-span-2">
                <button
                  type="submit"
                  disabled={loading}
                  className={cn(
                    "w-full py-3 px-4 rounded-lg text-white font-medium transition-all",
                    loading 
                      ? "bg-gray-400 cursor-not-allowed"
                      : "bg-blue-600 hover:bg-blue-700 active:bg-blue-800"
                  )}
                >
                  {loading ? (
                    <span className="flex items-center justify-center">
                      <Activity className="w-5 h-5 animate-spin mr-2" />
                      Processing...
                    </span>
                  ) : (
                    "Analyze Data"
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Results Section */}
          {prediction && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "rounded-lg p-6 text-center",
                prediction === 'Benign' 
                  ? "bg-green-100 text-green-800"
                  : "bg-red-100 text-red-800"
              )}
            >
              <div className="flex items-center justify-center mb-4">
                <AlertCircle className="w-8 h-8 mr-2" />
                <h3 className="text-2xl font-bold">
                  {prediction === 'Benign' ? 'Benign Tumor Detected' : 'Malignant Tumor Detected'}
                </h3>
              </div>
              <p className="text-lg">
                {prediction === 'Benign'
                  ? 'The analysis indicates a benign tumor. Regular check-ups are still recommended.'
                  : 'The analysis indicates a malignant tumor. Please consult with a healthcare professional immediately.'}
              </p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

export default App;